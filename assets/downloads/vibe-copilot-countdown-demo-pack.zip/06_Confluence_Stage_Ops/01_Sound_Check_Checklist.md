# Sound check checklist

Space: Stage Ops · Owner: Dee Alvarez

Use this for every band on the April's Analog stage. Budget 20 minutes for a four-piece, 30 for anything bigger.

## Before the band arrives (4:00 pm)
- Sound vendor (Loud & Clear Audio) is loaded in and the PA is line-checked
- PA and backline are on **separate 20-amp circuits** (the PA tripped the breaker twice at Analog Fest 2025)
- Monitor wedges placed: 3 for a four-piece, 4 for five or more
- Spare XLR cables, 2 DI boxes, gaffer tape, and a spare 9V battery at stage left

## Four-piece band (vocals/guitar, guitar, bass, drums)
1. Kick, snare, toms, overheads (5 minutes max)
2. Bass DI, then bass amp
3. Guitar amps, one at a time
4. Lead vocal, then backing vocal
5. Monitor mixes: ask each player what they need, one change at a time
6. Play one full song together. Check levels from the back of the room, not the stage.

## Before doors
- Walk-in music on at doors
- Set list taped to the stage floor
- Band knows the hard stop: **sound off by 11:00 pm** (city rule)

## Heads up
We don't have a house drum kit. If a band doesn't bring one, Loud & Clear rents one for $75 a night. Book it at least 3 days ahead.
