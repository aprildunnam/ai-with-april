# Load-in rules

Space: Stage Ops · Owner: Dee Alvarez

- Load-in is always **5:00 pm**, through the back door off the lot. Never through the shop floor while customers are in.
- Park in the two spots marked BAND. Move your vehicle by 6:00 pm.
- Gear stays against the east wall until your changeover.
- Changeovers are 20 minutes. Be ready to go on when the stage manager says so.
- Bands get 4 drink tickets each and 4 guest list spots. Send guest names to Dee by 3:00 pm day of.
- Pay: local bands get $200 flat plus 20% of the door, paid by check or Venmo at the end of the night.
- Merch: one 6-foot table near the exit. We take 0% of band merch.
