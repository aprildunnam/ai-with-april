# Stage plot: standard four-piece

Space: Stage Ops · Owner: Dee Alvarez

Stage size: 16 ft wide x 10 ft deep, 18-inch riser. Audience faces north.

```
                  [ DRUMS ]  (riser center back)
        [ BASS AMP ]                 [ GTR 2 AMP ]
 [ GTR 1 AMP ]
      (Bass)          (Vocal/Gtr 1)          (Gtr 2)
   [wedge 1]           [wedge 2]            [wedge 3]
 ------------------------ FRONT OF STAGE ------------------------
```

## Inputs (12 channels)
| Ch | Source | Mic/DI |
|---|---|---|
| 1 | Kick | Beta 52 |
| 2 | Snare | SM57 |
| 3 | Rack tom | e604 |
| 4 | Floor tom | e604 |
| 5-6 | Overheads | Condenser pair |
| 7 | Hi-hat | Condenser |
| 8 | Bass | DI |
| 9 | Guitar 1 | SM57 |
| 10 | Guitar 2 | SM57 |
| 11 | Lead vocal | SM58 |
| 12 | Backing vocal | SM58 |

Power: 2 outlets stage left, 2 stage right, all on the backline circuit (not the PA circuit).
