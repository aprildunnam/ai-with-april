Subject: New arrivals + a very important cat update

Hey friends,

Big week at the shop. We just got 40 copies of the Honey Hollow reissue on 180g, and it sounds like they're playing in your living room. Think of it like going from a phone speaker to front row.

Also, our shop cat Wax finally figured out the listening bar stools. He's not sharing.

Swing by Saturday. First 20 people get a free tote.

See you in the stacks, April
