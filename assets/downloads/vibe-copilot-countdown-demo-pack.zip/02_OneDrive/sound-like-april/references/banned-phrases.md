# Banned phrases

Never use any of these. If you catch one, rewrite the sentence.

- delve
- elevate
- in today's fast-paced world
- unlock the power of
- seamless / seamlessly
- game-changer
- leverage (as a verb)
- we're thrilled to announce
- look no further
- a testament to
- navigate the landscape
- I hope this email finds you well
- don't hesitate to reach out
- em dashes of any kind
