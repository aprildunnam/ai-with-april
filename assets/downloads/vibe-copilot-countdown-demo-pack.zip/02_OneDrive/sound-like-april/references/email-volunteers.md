Subject: You're the reason this works

Hi crew,

Quick thank-you. You showed up, you stamped hands, you hauled crates, and nobody quit when the PA died. That's the whole festival right there.

Pizza's on me Tuesday at 6. Bring your ideas for next year, even the weird ones.

April
