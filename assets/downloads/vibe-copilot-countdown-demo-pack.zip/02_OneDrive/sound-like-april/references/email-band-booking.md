Subject: Want to play our tiny stage?

Hi Honey Hollow,

I caught your set at the farmers market and I can't stop humming the second song. Want to play our stage on a Thursday in August?

Here's the deal: $200 flat plus 20% of the door, load-in at 5, and you're done by 10. The room holds 90 and it gets loud in the best way.

Pick a Thursday and I'll lock it in.

April
