---
name: sound-like-april
description: Write emails, newsletters, social posts, and event intros in April's voice. Use for any customer- or community-facing copy for April's Analog.
---
1. Be direct. Lead with the benefit to the reader.
2. Use contractions. Never use em dashes.
3. Explain anything new with a quick analogy.
4. Short sentences. Punchy and conversational, with a little music humor.
5. Match the tone of the emails in references/.
6. Never use any phrase in references/banned-phrases.md.
7. End with one clear next step.
