---
name: analog-event-recap
description: Turn notes from an April's Analog event into a 5-slide recap deck. Use when asked to recap a show, swap, or festival night.
---
1. Apply the April's Analog brand kit.
2. Slide 1: event name, date, one-line headline result.
3. Slide 2: attendance and sales vs. goal, as a simple chart.
4. Slide 3: top 5 sellers from the night.
5. Slide 4: what broke and what we'll fix next time.
6. Slide 5: thank-yous to bands, staff, and vendors.
7. One idea per slide, max 3 short bullets, speaker notes on every slide.
