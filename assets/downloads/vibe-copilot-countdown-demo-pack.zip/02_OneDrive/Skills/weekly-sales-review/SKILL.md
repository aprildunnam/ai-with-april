---
name: weekly-sales-review
description: Build the weekly sales review for April's Analog from a sales table. Use when asked for the weekly review or sales summary.
---
1. Add a sheet named Summary.
2. Total revenue and units by genre and format, compared to the prior week.
3. Flag any genre down more than 15% in red.
4. Chart the top 10 sellers by revenue.
5. Add 3 plain-English takeaways at the top.
6. Apply @brandkit styling.
