Cowork saves the Demo 2 meeting brief here. Create this folder in OneDrive: Analog Fest/Meetings
