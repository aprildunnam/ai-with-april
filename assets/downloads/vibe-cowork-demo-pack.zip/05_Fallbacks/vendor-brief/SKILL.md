---
name: vendor-brief
description: Prep a one-page meeting brief for any record label, distributor, or vendor April's Analog works with. Use when asked to prep for a vendor or label meeting or call.
---
1. Find the vendor in Vendor_Pipeline.xlsx. Pull their last order date, order size, and pop-up interest from the Labels and Orders sheets.
2. Search the last 6 months of email and Teams chats with the vendor's contact. Note open requests, problems (late shipments, invoice issues), and anything they asked for.
3. Write a one-page Word brief with these sections:
   - Where things stand (4 bullets max)
   - 3 talking points, each starting with the action in bold
   - Sources (list the emails, chats, and files you used)
4. Save it to /Analog Fest/Meetings/ named "Brief - <Vendor> - <date>.docx".
5. Keep it short and direct. Use contractions. No em dashes.
6. Show me a preview before you create the file.
